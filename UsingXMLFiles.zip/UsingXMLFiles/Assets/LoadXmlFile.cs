﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.IO;
using System.Xml;
using UnityEngine.UI;

public class LoadXmlFile : MonoBehaviour {
    //criação da variavel que vai receber o XML
    public TextAsset xmlRawFile;
    //Text que vai exibir o conteudo
    public Text uiText;
    private string userLogin, userPassword;
    public InputField IFLogin, IFPassword;

	// Use this for initialization
	void Start () {
       
        
	}

    public void login()
    {
        userLogin = IFLogin.text;
        userPassword = IFPassword.text;

        //cria a variavel que recebe o conteudo do XML
        string data = xmlRawFile.text;

        //chamad o metodo para abrir o conteudo do XML
        parseXmlFile(data);
    }

    void parseXmlFile(string xmlData)
    {
        //cria a variavel que vai acumular o conteudo lido do arquivo XML
        string totVal = "";
        //cria uma variavel da classe XMLDocument
        XmlDocument xmlDoc = new XmlDocument();
        //carrega o arquivo
        xmlDoc.Load(new StringReader(xmlData));
        //string que guarda os atributos iniciais do XML
        string xmlPath = "//Document/Data";
        //cria uma lista com as informações recebidas
        XmlNodeList myNodeList = xmlDoc.SelectNodes(xmlPath);

        foreach(XmlNode node in myNodeList)
        {
            XmlNode login = node.FirstChild;
            XmlNode password = login.NextSibling;
            XmlNode points = password.NextSibling;

            if (login.InnerXml == userLogin && password.InnerXml == userPassword)
            {
                totVal += " Login: " + login.InnerXml + "\n Password : " + password.InnerXml + "\n Points: " + points.InnerXml + "\n\n";
            }
        }

        uiText.text = totVal;
    }

	// Update is called once per frame
	void Update () {
		
	}
}
